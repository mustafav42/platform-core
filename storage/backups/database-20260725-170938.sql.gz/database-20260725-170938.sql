-- Restaurant Management System database backup
-- Created: 2026-07-25T17:09:38+03:00
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS=0;

DROP TABLE IF EXISTS `admins`;
CREATE TABLE `admins` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL,
  `email` varchar(190) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('admin','cashier') NOT NULL DEFAULT 'admin',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `last_login_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `admins` (`id`,`name`,`email`,`password_hash`,`role`,`is_active`,`last_login_at`,`created_at`) VALUES ('1','Yönetici','mustafav42@gmail.com','$2y$10$TtAc.VQ3.0tpVd4anTAGxuPrQcV1X8FVhUdUt78LnbciXeeau7oSm','admin','1','2026-07-25 17:06:02','2026-07-25 16:00:01');

DROP TABLE IF EXISTS `audit_logs`;
CREATE TABLE `audit_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `actor_type` enum('admin','staff','system') NOT NULL,
  `actor_id` bigint(20) unsigned DEFAULT NULL,
  `action` varchar(120) NOT NULL,
  `context_json` longtext DEFAULT NULL,
  `ip_hash` char(64) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_audit_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `backup_history`;
CREATE TABLE `backup_history` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `file_name` varchar(255) NOT NULL,
  `file_size` bigint(20) unsigned NOT NULL DEFAULT 0,
  `status` varchar(30) NOT NULL DEFAULT 'completed',
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_backup_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `cash_sessions`;
CREATE TABLE `cash_sessions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `opened_by_staff_id` int(10) unsigned NOT NULL,
  `closed_by_staff_id` int(10) unsigned DEFAULT NULL,
  `opening_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `expected_cash` decimal(12,2) DEFAULT NULL,
  `counted_cash` decimal(12,2) DEFAULT NULL,
  `difference_amount` decimal(12,2) DEFAULT NULL,
  `status` enum('open','closed') NOT NULL DEFAULT 'open',
  `note` varchar(500) DEFAULT NULL,
  `opened_at` datetime NOT NULL,
  `closed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_cash_status` (`status`,`opened_at`),
  KEY `fk_cash_open_staff` (`opened_by_staff_id`),
  KEY `fk_cash_close_staff` (`closed_by_staff_id`),
  CONSTRAINT `fk_cash_close_staff` FOREIGN KEY (`closed_by_staff_id`) REFERENCES `staff_users` (`id`),
  CONSTRAINT `fk_cash_open_staff` FOREIGN KEY (`opened_by_staff_id`) REFERENCES `staff_users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `cash_sessions` (`id`,`opened_by_staff_id`,`closed_by_staff_id`,`opening_amount`,`expected_cash`,`counted_cash`,`difference_amount`,`status`,`note`,`opened_at`,`closed_at`) VALUES ('1','3','3','0.00','100.00','100.00','0.00','closed','','2026-07-25 16:24:17','2026-07-25 16:25:52');
INSERT INTO `cash_sessions` (`id`,`opened_by_staff_id`,`closed_by_staff_id`,`opening_amount`,`expected_cash`,`counted_cash`,`difference_amount`,`status`,`note`,`opened_at`,`closed_at`) VALUES ('2','3',NULL,'0.00',NULL,NULL,NULL,'open',NULL,'2026-07-25 16:25:54',NULL);

DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `description` text DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `categories` (`id`,`name`,`description`,`sort_order`,`is_active`,`created_at`) VALUES ('1','Kahveler','','0','1','2026-07-25 16:00:25');

DROP TABLE IF EXISTS `dining_areas`;
CREATE TABLE `dining_areas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `dining_areas` (`id`,`name`,`sort_order`,`is_active`) VALUES ('1','Ana Salon','1','1');
INSERT INTO `dining_areas` (`id`,`name`,`sort_order`,`is_active`) VALUES ('2','Ön salon','0','1');

DROP TABLE IF EXISTS `order_items`;
CREATE TABLE `order_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint(20) unsigned NOT NULL,
  `product_id` int(10) unsigned DEFAULT NULL,
  `product_name` varchar(180) NOT NULL,
  `unit_price` decimal(12,2) NOT NULL,
  `quantity` decimal(8,2) NOT NULL DEFAULT 1.00,
  `item_note` varchar(500) DEFAULT NULL,
  `status` enum('active','cancelled','complimentary') NOT NULL DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_items_order` (`order_id`),
  KEY `fk_items_product` (`product_id`),
  CONSTRAINT `fk_items_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_items_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `order_items` (`id`,`order_id`,`product_id`,`product_name`,`unit_price`,`quantity`,`item_note`,`status`,`created_at`) VALUES ('1','1','1','Latte','100.00','1.00','','cancelled','2026-07-25 16:09:49');
INSERT INTO `order_items` (`id`,`order_id`,`product_id`,`product_name`,`unit_price`,`quantity`,`item_note`,`status`,`created_at`) VALUES ('2','2','1','Latte','100.00','1.00','bol stülü','active','2026-07-25 16:10:18');
INSERT INTO `order_items` (`id`,`order_id`,`product_id`,`product_name`,`unit_price`,`quantity`,`item_note`,`status`,`created_at`) VALUES ('3','3','1','Latte','100.00','3.00',NULL,'active','2026-07-25 16:40:16');
INSERT INTO `order_items` (`id`,`order_id`,`product_id`,`product_name`,`unit_price`,`quantity`,`item_note`,`status`,`created_at`) VALUES ('4','4','1','Latte','100.00','1.00',NULL,'active','2026-07-25 17:05:40');
INSERT INTO `order_items` (`id`,`order_id`,`product_id`,`product_name`,`unit_price`,`quantity`,`item_note`,`status`,`created_at`) VALUES ('5','5','1','Latte','100.00','1.00',NULL,'active','2026-07-25 17:05:47');
INSERT INTO `order_items` (`id`,`order_id`,`product_id`,`product_name`,`unit_price`,`quantity`,`item_note`,`status`,`created_at`) VALUES ('6','6','1','Latte','100.00','1.00',NULL,'active','2026-07-25 17:05:49');
INSERT INTO `order_items` (`id`,`order_id`,`product_id`,`product_name`,`unit_price`,`quantity`,`item_note`,`status`,`created_at`) VALUES ('7','7','1','Latte','100.00','1.00',NULL,'active','2026-07-25 17:05:49');
INSERT INTO `order_items` (`id`,`order_id`,`product_id`,`product_name`,`unit_price`,`quantity`,`item_note`,`status`,`created_at`) VALUES ('8','8','1','Latte','100.00','1.00',NULL,'active','2026-07-25 17:05:49');

DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `session_id` bigint(20) unsigned NOT NULL,
  `staff_id` int(10) unsigned DEFAULT NULL,
  `status` enum('draft','submitted','completed','cancelled') NOT NULL DEFAULT 'submitted',
  `note` varchar(500) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_orders_session` (`session_id`,`status`),
  KEY `fk_orders_staff` (`staff_id`),
  KEY `idx_orders_created_at` (`created_at`),
  CONSTRAINT `fk_orders_session` FOREIGN KEY (`session_id`) REFERENCES `table_sessions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_orders_staff` FOREIGN KEY (`staff_id`) REFERENCES `staff_users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `orders` (`id`,`session_id`,`staff_id`,`status`,`note`,`created_at`) VALUES ('1','1','1','submitted',NULL,'2026-07-25 16:09:49');
INSERT INTO `orders` (`id`,`session_id`,`staff_id`,`status`,`note`,`created_at`) VALUES ('2','1','1','submitted',NULL,'2026-07-25 16:10:18');
INSERT INTO `orders` (`id`,`session_id`,`staff_id`,`status`,`note`,`created_at`) VALUES ('3','2','3','submitted',NULL,'2026-07-25 16:40:16');
INSERT INTO `orders` (`id`,`session_id`,`staff_id`,`status`,`note`,`created_at`) VALUES ('4','3','3','submitted',NULL,'2026-07-25 17:05:40');
INSERT INTO `orders` (`id`,`session_id`,`staff_id`,`status`,`note`,`created_at`) VALUES ('5','4','3','submitted',NULL,'2026-07-25 17:05:47');
INSERT INTO `orders` (`id`,`session_id`,`staff_id`,`status`,`note`,`created_at`) VALUES ('6','4','3','submitted',NULL,'2026-07-25 17:05:49');
INSERT INTO `orders` (`id`,`session_id`,`staff_id`,`status`,`note`,`created_at`) VALUES ('7','4','3','submitted',NULL,'2026-07-25 17:05:49');
INSERT INTO `orders` (`id`,`session_id`,`staff_id`,`status`,`note`,`created_at`) VALUES ('8','4','3','submitted',NULL,'2026-07-25 17:05:49');

DROP TABLE IF EXISTS `payments`;
CREATE TABLE `payments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `table_session_id` bigint(20) unsigned DEFAULT NULL,
  `cash_session_id` bigint(20) unsigned DEFAULT NULL,
  `staff_id` int(10) unsigned DEFAULT NULL,
  `session_id` bigint(20) unsigned DEFAULT NULL,
  `method` enum('cash','card','credit_card','meal_card','transfer','other') NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `paid_at` datetime DEFAULT NULL,
  `received_by_admin_id` int(10) unsigned DEFAULT NULL,
  `note` varchar(500) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_payments_session` (`session_id`,`created_at`),
  KEY `fk_payments_admin` (`received_by_admin_id`),
  KEY `idx_payments_table` (`table_session_id`,`paid_at`),
  KEY `idx_payments_cash` (`cash_session_id`,`paid_at`),
  KEY `idx_payments_paid_at` (`paid_at`),
  CONSTRAINT `fk_payments_admin` FOREIGN KEY (`received_by_admin_id`) REFERENCES `admins` (`id`),
  CONSTRAINT `fk_payments_session` FOREIGN KEY (`session_id`) REFERENCES `table_sessions` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `payments` (`id`,`table_session_id`,`cash_session_id`,`staff_id`,`session_id`,`method`,`amount`,`paid_at`,`received_by_admin_id`,`note`,`created_at`) VALUES ('1','1','1','3',NULL,'cash','100.00','2026-07-25 16:25:43',NULL,NULL,NULL);
INSERT INTO `payments` (`id`,`table_session_id`,`cash_session_id`,`staff_id`,`session_id`,`method`,`amount`,`paid_at`,`received_by_admin_id`,`note`,`created_at`) VALUES ('2','2','2','3',NULL,'cash','100.00','2026-07-25 16:40:30',NULL,NULL,NULL);
INSERT INTO `payments` (`id`,`table_session_id`,`cash_session_id`,`staff_id`,`session_id`,`method`,`amount`,`paid_at`,`received_by_admin_id`,`note`,`created_at`) VALUES ('3','2','2','3',NULL,'cash','200.00','2026-07-25 16:40:42',NULL,NULL,NULL);

DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(10) unsigned NOT NULL,
  `name` varchar(180) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(12,2) NOT NULL DEFAULT 0.00,
  `image_path` varchar(255) DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_products_category` (`category_id`,`is_active`,`sort_order`),
  CONSTRAINT `fk_products_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `products` (`id`,`category_id`,`name`,`description`,`price`,`image_path`,`sort_order`,`is_active`,`created_at`) VALUES ('1','1','Latte','','100.00',NULL,'0','1','2026-07-25 16:00:35');

DROP TABLE IF EXISTS `receipt_print_logs`;
CREATE TABLE `receipt_print_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `table_session_id` bigint(20) unsigned NOT NULL,
  `receipt_type` enum('bill','payment') NOT NULL DEFAULT 'bill',
  `printed_by_type` enum('admin','cashier','system') NOT NULL DEFAULT 'system',
  `printed_by_id` bigint(20) unsigned DEFAULT NULL,
  `printed_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_receipt_session` (`table_session_id`,`printed_at`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `receipt_print_logs` (`id`,`table_session_id`,`receipt_type`,`printed_by_type`,`printed_by_id`,`printed_at`) VALUES ('1','3','bill','cashier','3','2026-07-25 17:00:11');
INSERT INTO `receipt_print_logs` (`id`,`table_session_id`,`receipt_type`,`printed_by_type`,`printed_by_id`,`printed_at`) VALUES ('2','3','payment','cashier','3','2026-07-25 17:00:45');
INSERT INTO `receipt_print_logs` (`id`,`table_session_id`,`receipt_type`,`printed_by_type`,`printed_by_id`,`printed_at`) VALUES ('3','3','bill','cashier','3','2026-07-25 17:00:49');
INSERT INTO `receipt_print_logs` (`id`,`table_session_id`,`receipt_type`,`printed_by_type`,`printed_by_id`,`printed_at`) VALUES ('4','3','payment','cashier','3','2026-07-25 17:00:53');

DROP TABLE IF EXISTS `restaurant_tables`;
CREATE TABLE `restaurant_tables` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `area_id` int(10) unsigned NOT NULL,
  `name` varchar(80) NOT NULL,
  `capacity` smallint(5) unsigned NOT NULL DEFAULT 4,
  `status` enum('empty','open','reserved','cleaning','disabled') NOT NULL DEFAULT 'empty',
  `position_x` int(11) NOT NULL DEFAULT 20,
  `position_y` int(11) NOT NULL DEFAULT 20,
  `width_px` smallint(5) unsigned NOT NULL DEFAULT 130,
  `height_px` smallint(5) unsigned NOT NULL DEFAULT 90,
  `shape` enum('rectangle','round') NOT NULL DEFAULT 'rectangle',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_area_table` (`area_id`,`name`),
  CONSTRAINT `fk_tables_area` FOREIGN KEY (`area_id`) REFERENCES `dining_areas` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `restaurant_tables` (`id`,`area_id`,`name`,`capacity`,`status`,`position_x`,`position_y`,`width_px`,`height_px`,`shape`,`is_active`) VALUES ('1','2','Masa 1','4','open','20','20','130','90','rectangle','1');
INSERT INTO `restaurant_tables` (`id`,`area_id`,`name`,`capacity`,`status`,`position_x`,`position_y`,`width_px`,`height_px`,`shape`,`is_active`) VALUES ('2','1','Masa 2','4','open','20','20','130','90','rectangle','1');

DROP TABLE IF EXISTS `settings`;
CREATE TABLE `settings` (
  `setting_key` varchar(190) NOT NULL,
  `setting_value` text DEFAULT NULL,
  PRIMARY KEY (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `settings` (`setting_key`,`setting_value`) VALUES ('app_version','2.8.0');
INSERT INTO `settings` (`setting_key`,`setting_value`) VALUES ('audit_retention_days','180');
INSERT INTO `settings` (`setting_key`,`setting_value`) VALUES ('automatic_backup_enabled','0');
INSERT INTO `settings` (`setting_key`,`setting_value`) VALUES ('backup_retention_days','14');
INSERT INTO `settings` (`setting_key`,`setting_value`) VALUES ('business_name','Cherry House');
INSERT INTO `settings` (`setting_key`,`setting_value`) VALUES ('currency_symbol','₺');
INSERT INTO `settings` (`setting_key`,`setting_value`) VALUES ('locale','tr-TR');
INSERT INTO `settings` (`setting_key`,`setting_value`) VALUES ('menu_enabled','1');
INSERT INTO `settings` (`setting_key`,`setting_value`) VALUES ('pos_enabled','1');
INSERT INTO `settings` (`setting_key`,`setting_value`) VALUES ('receipt_address','bursa ihsaniye');
INSERT INTO `settings` (`setting_key`,`setting_value`) VALUES ('receipt_auto_print','0');
INSERT INTO `settings` (`setting_key`,`setting_value`) VALUES ('receipt_footer','Afiyet olsun.');
INSERT INTO `settings` (`setting_key`,`setting_value`) VALUES ('receipt_paper_width','80');
INSERT INTO `settings` (`setting_key`,`setting_value`) VALUES ('receipt_phone','55555555555');
INSERT INTO `settings` (`setting_key`,`setting_value`) VALUES ('receipt_tax_info','nilüfer vd');
INSERT INTO `settings` (`setting_key`,`setting_value`) VALUES ('reports_enabled','1');
INSERT INTO `settings` (`setting_key`,`setting_value`) VALUES ('session_timeout_minutes','120');

DROP TABLE IF EXISTS `staff_users`;
CREATE TABLE `staff_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `pin_hash` varchar(255) DEFAULT NULL,
  `pin_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `role` enum('waiter','cashier','manager') NOT NULL DEFAULT 'waiter',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `last_login_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `idx_staff_pin_enabled` (`pin_enabled`,`is_active`,`role`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `staff_users` (`id`,`name`,`username`,`password_hash`,`pin_hash`,`pin_enabled`,`role`,`is_active`,`last_login_at`,`created_at`) VALUES ('1','Garson1','garson1','$2y$10$QgDeMdVQV7EerBA0sGCMGeZbu76YZNlNHYaGxdQ.O3zC3RBmk9D6u',NULL,'0','waiter','1','2026-07-25 16:09:32','2026-07-25 16:09:07');
INSERT INTO `staff_users` (`id`,`name`,`username`,`password_hash`,`pin_hash`,`pin_enabled`,`role`,`is_active`,`last_login_at`,`created_at`) VALUES ('2','Kasiyer','kasiyer','$2y$10$9GfXcaM/lhyq5kkxqB49YOhpNIeF8G6LNFNg86iztb9bwOkihrjnm',NULL,'0','cashier','0',NULL,'2026-07-25 16:17:08');
INSERT INTO `staff_users` (`id`,`name`,`username`,`password_hash`,`pin_hash`,`pin_enabled`,`role`,`is_active`,`last_login_at`,`created_at`) VALUES ('3','kasiyer','aaa','$2y$10$Fd8Rws8K0KNlMziptaKWWuDNI5XKIMyk4pgDR.hNZYFt.jH1.XIZW','$2y$10$YanB7pMC./R80n/PxSyIr.ZQLOoqxyn7kfuK6FJkdjtEezcWplPfa','1','cashier','1','2026-07-25 17:05:34','2026-07-25 16:18:16');
INSERT INTO `staff_users` (`id`,`name`,`username`,`password_hash`,`pin_hash`,`pin_enabled`,`role`,`is_active`,`last_login_at`,`created_at`) VALUES ('4','Mustafa','mustafa','$2y$10$jQd9ibw7ENg5ocf4JajJSO.LVqqA6XHHAimj1vHGFcDC7zlecHQ/W','$2y$10$/rUoxPZ6MJZbhuPOv0fIPe.mAFKfSMIF95J7o7bvjdDQdhpEI28gW','1','waiter','1',NULL,'2026-07-25 16:37:46');

DROP TABLE IF EXISTS `table_sessions`;
CREATE TABLE `table_sessions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `table_id` int(10) unsigned NOT NULL,
  `opened_by_staff_id` int(10) unsigned DEFAULT NULL,
  `guest_count` smallint(5) unsigned NOT NULL DEFAULT 1,
  `discount_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `discount_note` varchar(255) DEFAULT NULL,
  `status` enum('open','closed','cancelled') NOT NULL DEFAULT 'open',
  `opened_at` datetime NOT NULL,
  `closed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_sessions_status` (`status`,`opened_at`),
  KEY `fk_sessions_table` (`table_id`),
  KEY `fk_sessions_staff` (`opened_by_staff_id`),
  CONSTRAINT `fk_sessions_staff` FOREIGN KEY (`opened_by_staff_id`) REFERENCES `staff_users` (`id`),
  CONSTRAINT `fk_sessions_table` FOREIGN KEY (`table_id`) REFERENCES `restaurant_tables` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `table_sessions` (`id`,`table_id`,`opened_by_staff_id`,`guest_count`,`discount_amount`,`discount_note`,`status`,`opened_at`,`closed_at`) VALUES ('1','1','1','1','0.00',NULL,'closed','2026-07-25 16:09:44','2026-07-25 16:25:43');
INSERT INTO `table_sessions` (`id`,`table_id`,`opened_by_staff_id`,`guest_count`,`discount_amount`,`discount_note`,`status`,`opened_at`,`closed_at`) VALUES ('2','1','3','1','0.00',NULL,'closed','2026-07-25 16:40:15','2026-07-25 16:40:42');
INSERT INTO `table_sessions` (`id`,`table_id`,`opened_by_staff_id`,`guest_count`,`discount_amount`,`discount_note`,`status`,`opened_at`,`closed_at`) VALUES ('3','1','3','1','0.00',NULL,'open','2026-07-25 16:54:57',NULL);
INSERT INTO `table_sessions` (`id`,`table_id`,`opened_by_staff_id`,`guest_count`,`discount_amount`,`discount_note`,`status`,`opened_at`,`closed_at`) VALUES ('4','2','3','1','0.00',NULL,'open','2026-07-25 17:05:46',NULL);

SET FOREIGN_KEY_CHECKS=1;
